import express from "express";
import cors from "cors";
import { db } from "./firebase.js";
import { isMatch } from "./aiMatcher.js";
import crypto from "crypto";
import fetch from "node-fetch";
import dotenv from "dotenv";

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("VeriFind AI Backend Running");
});

/* POST ITEM + AI MATCHING */
app.post("/api/items", async (req, res) => {
  try {
    const item = req.body;

    const finalItem = {
      title: item.title,
      description: item.description || "",
      type: item.type,
      category: item.category,
      location: item.location,
      lat: item.lat || null,
      lng: item.lng || null,
      imageUrl: item.imageUrl || "",
      postedBy: item.postedBy,

      status: "available",
      createdAt: new Date().toISOString(),

      secretQuestion: item.type === "found" ? item.secretQuestion : null,
      secretAnswer: item.type === "found" ? item.secretAnswer : null,

      claimedBy: null,
      claimedAt: null,
      resolvedAt: null
    };

    // Save item
    const doc = await db.collection("items").add(finalItem);

    // AI matching
    const oppositeType = item.type === "lost" ? "found" : "lost";

    const snapshot = await db
      .collection("items")
      .where("type", "==", oppositeType)
      .where("status", "==", "available")
      .get();

    const matches = [];

    snapshot.forEach((d) => {
      const other = d.data();
      if (isMatch(finalItem, other)) {
        matches.push({ id: d.id, ...other });
      }
    });

    res.json({ success: true, id: doc.id, matches });

  } catch (err) {
    console.error("AI match error:", err);
    res.status(500).json({ error: "AI matching failed" });
  }
});

/* CLAIM ITEM (generates OTP + locks item) */
app.post("/api/claim", async (req, res) => {
  try {
    const { itemId, ownerId, finderId } = req.body;

    const otp = crypto.randomInt(100000, 999999).toString();

    await db.collection("otpSessions").doc(itemId).set({
      itemId,
      ownerId,
      finderId,
      otp,
      expiresAt: Date.now() + 10 * 60 * 1000,
      verified: false,
    });

    await db.collection("items").doc(itemId).update({
      status: "claimed",
      claimedBy: ownerId,
      claimedAt: new Date().toISOString(),
    });

    res.json({ success: true, otp });

  } catch (err) {
    console.error("Claim error:", err);
    res.status(500).json({ error: "Claim failed" });
  }
});

/* VERIFY OTP → RESOLVE ITEM */
app.post("/api/verify-otp", async (req, res) => {
  try {
    const { itemId, otp } = req.body;

    const snap = await db.collection("otpSessions").doc(itemId).get();

    if (!snap.exists) return res.json({ success: false });

    const session = snap.data();

    if (
      session.otp !== otp ||
      session.verified ||
      Date.now() > session.expiresAt
    ) {
      return res.json({ success: false });
    }

    await snap.ref.update({ verified: true });

    await db.collection("items").doc(itemId).update({
      status: "resolved",
      resolvedAt: new Date().toISOString(),
    });

    res.json({ success: true });

  } catch (err) {
    console.error("OTP verify error:", err);
    res.status(500).json({ success: false });
  }
});

app.post("/api/verify-secret", async (req, res) => {
  try {
    const { userAnswer, realAnswer } = req.body;

    const prompt = `
You are an AI verifier for a lost and found system.

A user is trying to prove ownership of an item.

Correct answer: "${realAnswer}"
User answer: "${userAnswer}"

Your job:
Decide if a human would reasonably accept these as referring to the same thing.

Rules:
- Ignore extra words
- Ignore missing words
- Ignore capitalization
- Allow partial matches
- Allow brand-only answers
- Allow synonyms
- If the user answer is a subset of the correct answer, it should be YES

Examples:
"prada" = "prada bag" → YES
"blue bottle" = "blue water bottle" → YES
"iphone" = "iphone 13 pro" → YES
"nike" = "nike shoes" → YES
"apple" = "samsung phone" → NO

Reply strictly with only YES or NO.
`;

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=" +
        process.env.GEMINI_KEY,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: prompt }],
            },
          ],
        }),
      }
    );

    const data = await response.json();

    console.log("Gemini raw response:", JSON.stringify(data, null, 2));

    const reply =
      data.candidates?.[0]?.content?.parts?.[0]?.text?.toLowerCase() || "";

    const correct = reply.includes("yes");
    res.json({ correct });
  } catch (err) {
    console.error("Gemini secret verify failed:", err);
    res.status(500).json({ correct: false });
  }
});

/* SERVER */
app.listen(4000, () => {
  console.log("🔥 VeriFind AI backend running on port 4000");
});
