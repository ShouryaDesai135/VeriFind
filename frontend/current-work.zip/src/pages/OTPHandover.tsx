import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { CheckCircle, Copy, Check, ArrowRight } from "lucide-react";
import { PageContainer } from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function OTPHandover() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const { item, otp } = state || {};

  if (!otp || !item) {
    return <p className="p-8 text-center">Invalid OTP session</p>;
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(otp);
    setCopied(true);
    toast({
      title: "Code copied!",
      description: "Share this code with the finder",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVerify = async () => {
    setVerifying(true);

    try {
      const res = await fetch("http://localhost:4000/api/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemId: item.id, otp }),
      });

      const data = await res.json();

      if (data.success) {
        toast({ title: "Item successfully returned!" });
        navigate("/dashboard");
      } else {
        toast({ title: "OTP not yet confirmed", variant: "destructive" });
      }
    } catch {
      toast({ title: "Server error", variant: "destructive" });
    }

    setVerifying(false);
  };

  return (
    <PageContainer withBottomNav={false}>
      <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
        <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center">
          <CheckCircle className="w-10 h-10 text-success" />
        </div>

        <h1 className="text-2xl font-bold mt-6">Handover Code</h1>
        <p className="text-muted-foreground mt-2">
          Give this code to the person who found your item
        </p>

        <div className="mt-8 w-full max-w-xs">
          <div className="bg-card border rounded-2xl p-6">
            <div className="flex justify-center gap-2 text-xl font-bold">
              {otp.split("").map((d, i) => (
                <div key={i} className="w-10 h-12 bg-secondary rounded-lg flex items-center justify-center">
                  {d}
                </div>
              ))}
            </div>

            <Button variant="outline" className="w-full mt-4" onClick={handleCopy}>
              {copied ? "Copied" : "Copy"}
            </Button>
          </div>
        </div>

        <Button
          className="mt-8 w-full max-w-xs"
          onClick={handleVerify}
          disabled={verifying}
        >
          OTP Verified by Finder
          <ArrowRight className="ml-2" />
        </Button>
      </div>
    </PageContainer>
  );
}
